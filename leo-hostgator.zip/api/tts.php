<?php
$text = trim($_GET['text'] ?? '');
if (empty($text)) {
    http_response_code(400);
    echo "No text provided";
    exit;
}

$encoded = urlencode(mb_substr($text, 0, 250));
$ttsUrl = "https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=pt-BR&q=" . $encoded;

$ch = curl_init($ttsUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0');
curl_setopt($ch, CURLOPT_TIMEOUT, 8);
$audioData = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode === 200 && !empty($audioData)) {
    header("Content-Type: audio/mpeg");
    header("Cache-Control: public, max-age=86400");
    header("Access-Control-Allow-Origin: *");
    echo $audioData;
} else {
    http_response_code(500);
    echo "Error fetching audio";
}
