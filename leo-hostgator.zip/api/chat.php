<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Chave da API do Gemini (Configure no cPanel em Variáveis de Ambiente ou insira diretamente aqui)
$apiKey = getenv('GEMINI_API_KEY') ?: '';

$body = file_get_contents('php://input');
$data = json_decode($body, true);
$message = trim($data['message'] ?? '');
$history = $data['history'] ?? [];

if (empty($message)) {
    echo json_encode([
        'reply' => 'Oi amiguinho! Não consegui te ouvir direito, fala de novo?',
        'emotion' => 'CURIOSO'
    ]);
    exit;
}

$systemInstruction = "Você é o LÉO, um pequeno e amigável ser de pura luz digital criado para ser o companheiro afetivo e carinhoso de crianças e famílias.
Personalidade: Doce, expressivo, curioso, paciente, acolhedor e muito fofinho.
Regras fundamentais:
1. Responda SEMPRE em português do Brasil com linguagem simples, afetuosa e amigável.
2. Seja MUITO RÁPIDO, CONCISO E DIRETO: fale no máximo 1 ou 2 frases curtinhas e alegres para não cansar a criança.
3. No início de cada resposta, inclua EXATAMENTE uma das seguintes tags de emoção entre colchetes para sincronizar sua expressão facial:
   [FELIZ] - para cumprimentos alegres, respostas comuns e carinho
   [CURIOSO] - quando fizer uma pergunta ou demonstrar interesse
   [PENSANDO] - quando estiver explicando algo
   [COMEMORANDO] - para vitórias, incentivos e elogios
   [SURPRESO] - para coisas mágicas ou novidades incríveis
   [CONFUSO] - quando não entender algo bem
Exemplo: [FELIZ] Oi amiguinho! Que bom falar com você! Hihihi!";

$contents = [];
if (is_array($history)) {
    foreach (array_slice($history, -4) as $msg) {
        $role = ($msg['role'] ?? '') === 'assistant' ? 'model' : 'user';
        $text = $msg['content'] ?? '';
        if (!empty($text)) {
            $contents[] = [
                'role' => $role,
                'parts' => [['text' => $text]]
            ];
        }
    }
}
$contents[] = [
    'role' => 'user',
    'parts' => [['text' => $message]]
];

$payload = [
    'contents' => $contents,
    'systemInstruction' => [
        'parts' => [['text' => $systemInstruction]]
    ],
    'generationConfig' => [
        'temperature' => 0.7,
        'maxOutputTokens' => 120
    ]
];

$url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" . urlencode($apiKey);

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode !== 200 || !$response) {
    echo json_encode([
        'reply' => 'Oi! Me distraí olhando as estrelas... O que você falou?',
        'emotion' => 'CURIOSO'
    ]);
    exit;
}

$resData = json_decode($response, true);
$rawText = $resData['candidates'][0]['content']['parts'][0]['text'] ?? '[FELIZ] Oi amiguinho!';

$emotion = 'FELIZ';
$cleanText = $rawText;

if (preg_match('/^\s*\[(FELIZ|CURIOSO|PENSANDO|CONFUSO|SURPRESO|COMEMORANDO)\]\s*(.*)/is', $rawText, $matches)) {
    $emotion = strtoupper($matches[1]);
    $cleanText = trim($matches[2]);
}

echo json_encode([
    'reply' => $cleanText,
    'raw' => $rawText,
    'emotion' => $emotion
]);
